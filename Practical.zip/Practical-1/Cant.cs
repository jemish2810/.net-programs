using System;
namespace Cant
{
	public class Cant
	{
		public static void Main()
		{
			int a;
			a = 99;
			Console.WriteLine("Value is: {0}",a);

			Console.ReadKey();
		}
	}
}