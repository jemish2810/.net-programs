using System;

namespace P1
{
	public class Char
	{
		public static void Main()
		{
			char c = 'm';
			Console.WriteLine(c);
		}
	}
}