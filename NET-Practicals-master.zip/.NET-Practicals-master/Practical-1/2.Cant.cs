using System;
namespace Cant
{
	public class Cant
	{
		public static void Main()
		{
			int a;
			a = 99; //without this following line will raise an error
			Console.WriteLine("Value is: {0}",a);

			Console.ReadKey();
		}
	}
}