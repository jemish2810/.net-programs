using System;
namespace P1
{
	class MyFirstClass
	{
		public static void Main()
		{
			Console.WriteLine("HiAll");
			Console.ReadKey();
			return;
		}
	}
}