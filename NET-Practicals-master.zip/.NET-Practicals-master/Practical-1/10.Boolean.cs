using System;
1
namespace P1
{
	public class Boolean
	{
		public static void Main()
		{
			bool status = true;
			Console.WriteLine(status);
		}
	}
}