using System;
namespace P1
{
	public class Scope{
	static int j = 430;
	public static void Main()
	{
		int j =900;
		Console.WriteLine(Scope.j);
	}}
}